namespace go follow

service FollowService {

  // 查询是否关注
	bool IsFollowing(1: i64 userId, 2: i64 followerId)

}
