namespace go publish

include "thrift/timestamp.thrift"

// 视频信息
struct VideoInfo {
	1: i64 id
	2: i64 author_id
	3: string play_url
	4: string cover_url
	5: i64 favorite_count
	6: i64 comment_count
	7: string title
}

service PublishService {

	// 更新评论数
	void UpdateCommentCount(1: i64 videoId, 2: i64 newCommentCount)

	// 更新获赞数
	void UpdateFavoriteCount(1: i64 videoId, 2: i64 newFavoriteCount)  

	// 查询最近视频
	list<VideoInfo> QueryRecentVideoInfos(1: timestamp startTime, 2: i64 limit)

	// 获取视频信息
	VideoInfo VideoInfo(1: i64 videoId)

}

