namespace go message

// 消息
struct Message {
	1: required i64 id
	2: required i64 sender_id
	3: required i64 receiver_id
	4: required string content
	5: optional string send_time
}

service MessageService {

  // 获取最新消息
	Message LatestMessage(1: i64 senderId, 2: i64 receiverId)

}
