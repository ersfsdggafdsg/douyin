namespace go user

// 用户信息
struct UserInfo {
  1: i64 id
  2: string name
  3: i64 follow_count
  4: i64 follower_count
  5: bool is_follow
  6: string avatar
  7: string background_image
  8: string signature
  9: i64 total_favorited
  10: i64 work_count
  11: i64 favorite_count
}

service UserService {

  // 获取用户信息
  UserInfo UserInfo(1: i64 userId)

  // 更新获赞数量
  void UpdateFavoritedCount(1: i64 userId, 2: i64 newFavoritedCount)

  // 更新关注数和粉丝数
  void UpdateFollowingAndFollowerCount(1: i64 userId, 2: i64 newFollowingCount, 3: i64 newFollowerCount)

}
