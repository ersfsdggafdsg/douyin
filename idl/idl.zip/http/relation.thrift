namespace go relation

// 关注/取消关注请求
struct douyin_relation_action_request {
  1: string token
  2: i64 to_user_id
  3: i32 action_type // 1-关注,2-取消关注
}

// 关注/取消关注响应
struct douyin_relation_action_response {
  1: i32 status_code
  2: string status_msg 
}

// 获取关注列表请求
struct douyin_relation_follow_list_request {
  1: i64 user_id
  2: string token
}

// 获取关注列表响应
struct douyin_relation_follow_list_response {
  1: i32 status_code
  2: string status_msg
  3: list<User> user_list
}

// 获取粉丝列表请求
struct douyin_relation_follower_list_request {
  1: i64 user_id
  2: string token
} 

// 获取粉丝列表响应
struct douyin_relation_follower_list_response {
  1: i32 status_code
  2: string status_msg
  3: list<User> user_list
}

// 用户信息
struct User {
  1: i64 id
  2: string name
  3: i64 follow_count
  4: i64 follower_count
  5: bool is_follow
  6: string avatar
  7: string background_image
  8: string signature
  9: i64 total_favorited
  10: i64 work_count
  11: i64 favorite_count
}

// 好友列表请求
struct douyin_relation_friend_list_request {
  1: i64 user_id
  2: string token
}

// 好友列表响应
struct douyin_relation_friend_list_response {
  1: i32 status_code
  2: string status_msg
  3: list<FriendUser> user_list  
}

// 好友用户信息
struct FriendUser {
  1: i64 id
  2: string name
  3: i64 follow_count
  4: i64 follower_count
  5: bool is_follow
  6: string avatar
  7: string background_image
  8: string signature
  9: i64 total_favorited
  10: i64 work_count
  11: i64 favorite_count
  12: string message
  13: i64 msgType
}

service RelationService {
  
  douyin_relation_action_response RelationAction(1: douyin_relation_action_request req)
    (api.post = "/douyin/relation/action")
  
  douyin_relation_follow_list_response FollowList(1: douyin_relation_follow_list_request req)
    (api.get = "/douyin/relation/follow/list")

  douyin_relation_follower_list_response FollowerList(1: douyin_relation_follower_list_request req)
    (api.get = "/douyin/relation/follower/list")

  douyin_relation_friend_list_response FriendList(1: douyin_relation_friend_list_request req)
	(api.get = "/douyin/relation/friend/list")
}
