namespace go publish

// 获取发布视频列表请求
struct douyin_publish_list_request {
  1: i64 user_id
  2: string token
}

// 获取发布视频列表响应
struct douyin_publish_list_response {
  1: i32 status_code
  2: string status_msg
  3: list<Video> video_list
}

// 视频信息
struct Video {
  1: i64 id
  2: User author
  3: string play_url
  4: string cover_url
  5: i64 favorite_count
  6: i64 comment_count
  7: bool is_favorite
  8: string title  
}

// 用户信息
struct User {
  1: i64 id
  2: string name
  3: i64 follow_count
  4: i64 follower_count
  5: bool is_follow
  6: string avatar
  7: string background_image
  8: string signature
  9: i64 total_favorited
  10: i64 work_count
  11: i64 favorite_count
}

// 发布视频请求
struct douyin_publish_action_request {
  1: string token
  2: binary data
  3: string title
}

// 发布视频响应
struct douyin_publish_action_response {
  1: i32 status_code
  2: string status_msg
}

service PublishService {

  // 获取发布视频列表
  douyin_publish_list_response PublishList(1: douyin_publish_list_request request)
    (api.get = "/douyin/publish/list")

  // 发布视频
  douyin_publish_action_response PublishAction(1: douyin_publish_action_request request)
    (api.post = "/douyin/publish/action")

}
